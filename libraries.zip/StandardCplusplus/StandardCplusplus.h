#undef abs
