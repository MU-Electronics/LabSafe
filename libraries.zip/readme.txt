# What is this repo #
This repo contains libraries used when developing with the ardunio framework by the Electronics Section Manchester University